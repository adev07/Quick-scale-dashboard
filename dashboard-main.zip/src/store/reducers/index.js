import { combineReducers } from "redux";
import dashboard from "./Dashboard.js";

export default combineReducers({
    dashboard
})
